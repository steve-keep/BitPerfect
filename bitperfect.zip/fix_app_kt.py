filepath = 'app/src/main/kotlin/com/bitperfect/app/BitPerfectApplication.kt'
with open(filepath, 'r') as f:
    app_kt = f.read()

if 'UsbDacOutputPlugin' not in app_kt:
    app_kt = app_kt.replace('import android.app.Application', 'import android.app.Application\nimport com.bitperfect.core.output.OutputPluginRegistry\nimport com.bitperfect.plugin.usbdac.UsbDacOutputPlugin')
    app_kt = app_kt.replace('class BitPerfectApplication : Application(), ImageLoaderFactory {', 'class BitPerfectApplication : Application(), ImageLoaderFactory {\n\n    val outputPluginRegistry = OutputPluginRegistry()')
    app_kt = app_kt.replace('super.onCreate()', 'super.onCreate()\n        outputPluginRegistry.register(UsbDacOutputPlugin(this))')
    
    with open(filepath, 'w') as f:
        f.write(app_kt)

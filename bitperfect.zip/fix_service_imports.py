with open('app/src/main/kotlin/com/bitperfect/app/player/PlaybackService.kt', 'r') as f:
    c = f.read()

import re
imports = '''
import com.bitperfect.plugin.usbdac.UsbAudioRenderersFactory
import com.bitperfect.core.output.CoreTrackInfo
import com.bitperfect.core.output.PlaybackHandoffState
import com.bitperfect.core.output.PlayerProvider
import com.bitperfect.app.BitPerfectApplication
'''

# Find last import
matches = list(re.finditer(r'^import .+$', c, re.MULTILINE))
if matches:
    last = matches[-1].end()
    c = c[:last] + "\n" + imports + c[last:]

with open('app/src/main/kotlin/com/bitperfect/app/player/PlaybackService.kt', 'w') as f:
    f.write(c)

# DeviceStateManager missing imports?
with open('app/src/main/kotlin/com/bitperfect/app/usb/DeviceStateManager.kt', 'r') as f:
    dsm = f.read()

dsm = dsm.replace('import com.bitperfect.app.usb.UsbDacState', 'import com.bitperfect.plugin.usbdac.UsbDacState')
dsm = dsm.replace('import com.bitperfect.app.usb.UsbAudioDacDetector', 'import com.bitperfect.plugin.usbdac.UsbAudioDacDetector')

matches2 = list(re.finditer(r'^import .+$', dsm, re.MULTILINE))
if matches2 and 'import com.bitperfect.plugin.usbdac.UsbDacState' not in dsm:
    last2 = matches2[-1].end()
    dsm = dsm[:last2] + "\nimport com.bitperfect.plugin.usbdac.UsbDacState\nimport com.bitperfect.plugin.usbdac.UsbAudioDacDetector" + dsm[last2:]

with open('app/src/main/kotlin/com/bitperfect/app/usb/DeviceStateManager.kt', 'w') as f:
    f.write(dsm)


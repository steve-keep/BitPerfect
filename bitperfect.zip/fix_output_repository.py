import re

filepath = 'app/src/main/kotlin/com/bitperfect/app/output/OutputRepository.kt'
with open(filepath, 'r') as f:
    content = f.read()

# Add the import
if 'import com.bitperfect.app.BitPerfectApplication' not in content:
    content = content.replace('import com.bitperfect.core.output.OutputDevice', 'import com.bitperfect.core.output.OutputDevice\nimport com.bitperfect.app.BitPerfectApplication')

# 1. In init block, replace the DeviceStateManager.dacState.collect with registry collector
dac_collect_regex = r'DeviceStateManager\.dacState\.collect \{ dacState ->.*?_availableDevices\.value = current.*?_activeDevice\.value is OutputDevice\.UsbDac\).*?\}'
replacement_init = '''val registry = (context.applicationContext as BitPerfectApplication).outputPluginRegistry
        scope.launch {
            registry.availableDevices.collect { pluginDevices ->
                val current = _availableDevices.value
                    .filter { it is OutputDevice.ThisPhone || it is OutputDevice.Bluetooth || it is OutputDevice.Upnp }
                    .toMutableList()
                current.addAll(pluginDevices)
                _availableDevices.value = current

                val active = _activeDevice.value
                if (active is OutputDevice.UsbDac && pluginDevices.none { it is OutputDevice.UsbDac }) {
                    Log.w("OutputRepository", "USB DAC disconnected while active — falling back to ThisPhone")
                    switchTo(OutputDevice.ThisPhone, emptyList(), 0)
                }
            }
        }'''
content = re.sub(dac_collect_regex, replacement_init, content, flags=re.DOTALL)

# 2. In refreshDevices, replace existingUsbDac logic
refresh_dac_regex = r'// Keep existing UsbDac devices\s*val existingUsbDac = _availableDevices\.value\.filterIsInstance<OutputDevice\.UsbDac>\(\)\s*devices\.addAll\(existingUsbDac\)'
replacement_refresh = '''// Add plugin devices
            val registry = (context.applicationContext as BitPerfectApplication).outputPluginRegistry
            devices.addAll(registry.availableDevices.value)'''
content = re.sub(refresh_dac_regex, replacement_refresh, content, flags=re.DOTALL)

with open(filepath, 'w') as f:
    f.write(content)

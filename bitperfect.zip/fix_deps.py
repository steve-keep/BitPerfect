import re
with open('app/build.gradle', 'r') as f:
    c = f.read()
c = re.sub(r'(dependencies \{)', r'\1\n    implementation project(":plugin-usb-dac")', c)
with open('app/build.gradle', 'w') as f:
    f.write(c)

import re

filepath = 'app/src/main/kotlin/com/bitperfect/app/player/PlaybackService.kt'
with open(filepath, 'r') as f:
    content = f.read()

if 'import com.bitperfect.app.BitPerfectApplication' not in content:
    content = content.replace('import com.bitperfect.core.output.OutputDevice', 'import com.bitperfect.core.output.OutputDevice\nimport com.bitperfect.app.BitPerfectApplication\nimport com.bitperfect.core.output.CoreTrackInfo\nimport com.bitperfect.core.output.PlaybackHandoffState\nimport com.bitperfect.core.output.PlayerProvider\nimport com.bitperfect.plugin.usbdac.UsbAudioRenderersFactory')

# Add activeProvider
content = content.replace('private var wiimCastPlayer: WiimCastPlayer? = null', 'private var wiimCastPlayer: WiimCastPlayer? = null\n    private var activeProvider: PlayerProvider? = null')

# Replace the UsbDac arm in handleDeviceSwitch
usbdac_arm = r'''is OutputDevice\.UsbDac -> \{
                    srv\.wiimCastPlayer\?\.release\(\)
                    srv\.wiimCastPlayer = null

                    val currentPosition = srv\.player\?\.currentPosition \?: 0L
                    val wasPlaying = srv\.player\?\.isPlaying \?: false
                    val currentMediaItem = srv\.player\?\.currentMediaItem

                    srv\.player\?\.release\(\)
                    val newPlayer = srv\.buildExoPlayer\(useUsbAudioSink = true\)
                    srv\.player = newPlayer
                    currentMediaItem\?\.let \{ newPlayer\.setMediaItem\(it, currentPosition\) \}
                    newPlayer\.prepare\(\)
                    if \(wasPlaying\) newPlayer\.play\(\)

                    srv\.session\.player = newPlayer
                \}'''

replacement_arm = '''is OutputDevice.UsbDac -> {
                    srv.wiimCastPlayer?.release()
                    srv.wiimCastPlayer = null

                    val registry = (srv.application as BitPerfectApplication).outputPluginRegistry
                    val plugin = registry.pluginFor(target)

                    if (plugin != null) {
                        val handoff = srv.buildHandoffState()
                        val provider = plugin.createPlayerProvider(srv, target, handoff)
                        srv.activeProvider?.release()
                        srv.activeProvider = provider
                        srv.player?.release()
                        srv.player = null
                        srv.session.player = provider.player
                    } else {
                        val currentPosition = srv.player?.currentPosition ?: 0L
                        val wasPlaying = srv.player?.isPlaying ?: false
                        val currentMediaItem = srv.player?.currentMediaItem

                        srv.player?.release()
                        val newPlayer = srv.buildExoPlayer(useUsbAudioSink = true)
                        srv.player = newPlayer
                        currentMediaItem?.let { newPlayer.setMediaItem(it, currentPosition) }
                        newPlayer.prepare()
                        if (wasPlaying) newPlayer.play()

                        srv.session.player = newPlayer
                    }
                }'''

content = re.sub(usbdac_arm, replacement_arm, content, flags=re.DOTALL)

# Add buildHandoffState
handoff_method = '''
    private fun buildHandoffState(): PlaybackHandoffState {
        val currentPlayer = player
        val items = (0 until (currentPlayer?.mediaItemCount ?: 0)).map { i ->
            currentPlayer!!.getMediaItemAt(i)
        }
        val tracks = items.map { item ->
            val meta = item.mediaMetadata
            CoreTrackInfo(
                id           = item.mediaId.toLongOrNull() ?: 0L,
                title        = meta.title?.toString() ?: "",
                artist       = meta.artist?.toString() ?: "",
                albumTitle   = meta.albumTitle?.toString() ?: "",
                durationMs   = 0L,
                trackNumber  = meta.trackNumber ?: 0,
                filePath     = null,
                dataPath     = null,
                albumId      = -1L,
            )
        }
        return PlaybackHandoffState(
            tracks        = tracks,
            currentIndex  = currentPlayer?.currentMediaItemIndex ?: 0,
            positionMs    = currentPlayer?.currentPosition ?: 0L,
            playWhenReady = currentPlayer?.playWhenReady ?: false,
        )
    }

    private fun buildExoPlayer'''

content = content.replace('    private fun buildExoPlayer', handoff_method)

# Add activeProvider.release() to onDestroy
content = content.replace('wiimCastPlayer?.release()', 'activeProvider?.release()\n        activeProvider = null\n        wiimCastPlayer?.release()')

# Add activeProvider.release() to local audio switch
content = content.replace('srv.wiimCastPlayer = null', 'srv.wiimCastPlayer = null\n                    srv.activeProvider?.release()\n                    srv.activeProvider = null')

with open(filepath, 'w') as f:
    f.write(content)

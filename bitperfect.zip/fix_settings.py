with open('settings.gradle', 'r') as f:
    c = f.read()
c = c.replace("include ':app', ':core'", "include ':app', ':core', ':plugin-usb-dac'")
with open('settings.gradle', 'w') as f:
    f.write(c)

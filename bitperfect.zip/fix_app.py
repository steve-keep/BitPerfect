filepath = 'app/src/main/kotlin/com/bitperfect/app/BitPerfectApplication.kt'
with open(filepath, 'r') as f:
    content = f.read()

if 'import com.bitperfect.core.output.OutputPluginRegistry' not in content:
    content = content.replace('import android.app.Application', 'import android.app.Application\nimport com.bitperfect.core.output.OutputPluginRegistry\nimport com.bitperfect.plugin.usbdac.UsbDacOutputPlugin')
    content = content.replace('class BitPerfectApplication : Application(), ImageLoaderFactory {', 'class BitPerfectApplication : Application(), ImageLoaderFactory {\n\n    val outputPluginRegistry = OutputPluginRegistry()')
    content = content.replace('super.onCreate()', 'super.onCreate()\n        outputPluginRegistry.register(UsbDacOutputPlugin(this))')

with open(filepath, 'w') as f:
    f.write(content)

import re

# 1. settings.gradle
with open('settings.gradle', 'r') as f:
    settings = f.read()
if "':plugin-usb-dac'" not in settings:
    settings = settings.replace("include ':app', ':core'", "include ':app', ':core', ':plugin-usb-dac'")
with open('settings.gradle', 'w') as f:
    f.write(settings)

# 2. app/build.gradle
with open('app/build.gradle', 'r') as f:
    build = f.read()
if "project(':plugin-usb-dac')" not in build:
    build = re.sub(r'(dependencies \{)', r'\1\n    implementation project(":plugin-usb-dac")', build)
with open('app/build.gradle', 'w') as f:
    f.write(build)

# 3. BitPerfectApplication.kt
with open('app/src/main/kotlin/com/bitperfect/app/BitPerfectApplication.kt', 'r') as f:
    app_kt = f.read()
if 'UsbDacOutputPlugin' not in app_kt:
    app_kt = app_kt.replace('import android.app.Application', 'import android.app.Application\nimport com.bitperfect.core.output.OutputPluginRegistry\nimport com.bitperfect.plugin.usbdac.UsbDacOutputPlugin')
    app_kt = app_kt.replace('class BitPerfectApplication : Application(), ImageLoaderFactory {', 'class BitPerfectApplication : Application(), ImageLoaderFactory {\n\n    val outputPluginRegistry = OutputPluginRegistry()')
    app_kt = app_kt.replace('// TODO Phase 2: register(UsbDacOutputPlugin(this))', 'outputPluginRegistry.register(UsbDacOutputPlugin(this))')
with open('app/src/main/kotlin/com/bitperfect/app/BitPerfectApplication.kt', 'w') as f:
    f.write(app_kt)

# 4. OutputRepository.kt
with open('app/src/main/kotlin/com/bitperfect/app/output/OutputRepository.kt', 'r') as f:
    repo = f.read()

# Fix import
repo = repo.replace('import com.bitperfect.app.usb.UsbDacState', 'import com.bitperfect.app.BitPerfectApplication')

# Fix init block
dac_collect_regex = r'DeviceStateManager\.dacState\.collect \{ dacState ->.*?_activeDevice\.value is OutputDevice\.UsbDac\).*?\}'
replacement_init = '''val registry = (context.applicationContext as BitPerfectApplication).outputPluginRegistry
            registry.availableDevices.collect { pluginDevices ->
                val current = _availableDevices.value
                    .filter { it is OutputDevice.ThisPhone || it is OutputDevice.Bluetooth || it is OutputDevice.Upnp }
                    .toMutableList()
                current.addAll(pluginDevices)
                _availableDevices.value = current

                val active = _activeDevice.value
                if (active is OutputDevice.UsbDac && pluginDevices.none { it is OutputDevice.UsbDac }) {
                    Log.w("OutputRepository", "USB DAC disconnected while active — falling back to ThisPhone")
                    switchTo(OutputDevice.ThisPhone, emptyList(), 0)
                }
            }'''
repo = re.sub(dac_collect_regex, replacement_init, repo, flags=re.DOTALL)

# Fix refreshDevices block
refresh_dac_regex = r'// Keep existing UsbDac devices\s*val existingUsbDac = _availableDevices\.value\.filterIsInstance<OutputDevice\.UsbDac>\(\)\s*devices\.addAll\(existingUsbDac\)'
replacement_refresh = '''// Add plugin devices
            val registry = (context.applicationContext as BitPerfectApplication).outputPluginRegistry
            devices.addAll(registry.availableDevices.value)'''
repo = re.sub(refresh_dac_regex, replacement_refresh, repo, flags=re.DOTALL)

with open('app/src/main/kotlin/com/bitperfect/app/output/OutputRepository.kt', 'w') as f:
    f.write(repo)

# 5. PlaybackService.kt
with open('app/src/main/kotlin/com/bitperfect/app/player/PlaybackService.kt', 'r') as f:
    srv = f.read()

srv = srv.replace('import com.bitperfect.app.player.UsbAudioRenderersFactory', 
                  'import com.bitperfect.plugin.usbdac.UsbAudioRenderersFactory\nimport com.bitperfect.core.output.CoreTrackInfo\nimport com.bitperfect.core.output.PlaybackHandoffState\nimport com.bitperfect.core.output.PlayerProvider\nimport com.bitperfect.app.BitPerfectApplication')

srv = srv.replace('private var wiimCastPlayer: WiimCastPlayer? = null', 'private var wiimCastPlayer: WiimCastPlayer? = null\n    private var activeProvider: PlayerProvider? = null')

usbdac_arm = r'''is OutputDevice\.UsbDac -> \{
                    srv\.wiimCastPlayer\?\.release\(\)
                    srv\.wiimCastPlayer = null

                    val currentPosition = srv\.player\?\.currentPosition \?: 0L
                    val wasPlaying = srv\.player\?\.isPlaying \?: false
                    val currentMediaItem = srv\.player\?\.currentMediaItem

                    srv\.player\?\.release\(\)
                    val newPlayer = srv\.buildExoPlayer\(useUsbAudioSink = true\)
                    srv\.player = newPlayer
                    currentMediaItem\?\.let \{ newPlayer\.setMediaItem\(it, currentPosition\) \}
                    newPlayer\.prepare\(\)
                    if \(wasPlaying\) newPlayer\.play\(\)

                    srv\.session\.player = newPlayer
                \}'''

replacement_arm = '''is OutputDevice.UsbDac -> {
                    srv.wiimCastPlayer?.release()
                    srv.wiimCastPlayer = null

                    val registry = (srv.application as BitPerfectApplication).outputPluginRegistry
                    val plugin = registry.pluginFor(target)

                    if (plugin != null) {
                        val handoff = srv.buildHandoffState()
                        val provider = plugin.createPlayerProvider(srv, target, handoff)
                        srv.activeProvider?.release()
                        srv.activeProvider = provider
                        srv.player?.release()
                        srv.player = null
                        srv.session.player = provider.player
                    } else {
                        val currentPosition = srv.player?.currentPosition ?: 0L
                        val wasPlaying = srv.player?.isPlaying ?: false
                        val currentMediaItem = srv.player?.currentMediaItem

                        srv.player?.release()
                        val newPlayer = srv.buildExoPlayer(useUsbAudioSink = true)
                        srv.player = newPlayer
                        currentMediaItem?.let { newPlayer.setMediaItem(it, currentPosition) }
                        newPlayer.prepare()
                        if (wasPlaying) newPlayer.play()

                        srv.session.player = newPlayer
                    }
                }'''
srv = re.sub(usbdac_arm, replacement_arm, srv, flags=re.DOTALL)

handoff_method = '''
    private fun buildHandoffState(): PlaybackHandoffState {
        val currentPlayer = player
        val items = (0 until (currentPlayer?.mediaItemCount ?: 0)).map { i ->
            currentPlayer!!.getMediaItemAt(i)
        }
        val tracks = items.map { item ->
            val meta = item.mediaMetadata
            CoreTrackInfo(
                id           = item.mediaId.toLongOrNull() ?: 0L,
                title        = meta.title?.toString() ?: "",
                artist       = meta.artist?.toString() ?: "",
                albumTitle   = meta.albumTitle?.toString() ?: "",
                durationMs   = 0L,
                trackNumber  = meta.trackNumber ?: 0,
                filePath     = null,
                dataPath     = null,
                albumId      = -1L,
            )
        }
        return PlaybackHandoffState(
            tracks        = tracks,
            currentIndex  = currentPlayer?.currentMediaItemIndex ?: 0,
            positionMs    = currentPlayer?.currentPosition ?: 0L,
            playWhenReady = currentPlayer?.playWhenReady ?: false,
        )
    }

    private fun buildExoPlayer'''
srv = srv.replace('    private fun buildExoPlayer', handoff_method)

srv = srv.replace('wiimCastPlayer?.release()', 'activeProvider?.release()\n        activeProvider = null\n        wiimCastPlayer?.release()')
srv = srv.replace('srv.wiimCastPlayer = null\n\n                    if (srv.isUsingUsbAudioSink)', 'srv.wiimCastPlayer = null\n                    srv.activeProvider?.release()\n                    srv.activeProvider = null\n\n                    if (srv.isUsingUsbAudioSink)')

with open('app/src/main/kotlin/com/bitperfect/app/player/PlaybackService.kt', 'w') as f:
    f.write(srv)


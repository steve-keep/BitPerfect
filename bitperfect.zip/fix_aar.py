import re

# 1. Update plugin-usb-dac/build.gradle
with open('plugin-usb-dac/build.gradle', 'r') as f:
    lib_gradle = f.read()

lib_gradle = lib_gradle.replace("implementation fileTree(dir: 'libs', include: ['*.aar'])", "compileOnly fileTree(dir: 'libs', include: ['*.aar'])")

with open('plugin-usb-dac/build.gradle', 'w') as f:
    f.write(lib_gradle)

# 2. Update app/build.gradle
with open('app/build.gradle', 'r') as f:
    app_gradle = f.read()

# Make sure it's not already there
if "implementation fileTree(dir: '../plugin-usb-dac/libs'" not in app_gradle:
    app_gradle = re.sub(r'(dependencies \{)', r'\1\n    implementation fileTree(dir: "../plugin-usb-dac/libs", include: ["*.aar"])', app_gradle)

with open('app/build.gradle', 'w') as f:
    f.write(app_gradle)


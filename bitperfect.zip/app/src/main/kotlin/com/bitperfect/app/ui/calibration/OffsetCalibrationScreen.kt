package com.bitperfect.app.ui.calibration

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import android.content.Intent
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.foundation.clickable
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.foundation.layout.ColumnScope
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bitperfect.core.services.DriveOffsetRepository
import kotlinx.coroutines.delay

sealed class CalibrationStepState {
    data object WaitingForDisc : CalibrationStepState()
    data object CheckingDisc : CalibrationStepState()
    data class NotAKeyDisc(val discTitle: String?, val attemptedUrl: String? = null) : CalibrationStepState()
    data class KeyDiscConfirmed(val discTitle: String?) : CalibrationStepState()
    data class Scanning(val progress: Float, val phase: String) : CalibrationStepState()
    data object Success : CalibrationStepState()
    data class Error(
        val message: String,
        val attemptedUrl: String? = null,
        val debugInfo: CalibrationDebugInfo? = null
    ) : CalibrationStepState()
}

val CalibrationStepStateListSaver = listSaver<MutableList<CalibrationStepState>, String>(
    save = { stateList ->
        stateList.map { state ->
            when (state) {
                is CalibrationStepState.WaitingForDisc -> "WaitingForDisc"
                is CalibrationStepState.CheckingDisc -> "CheckingDisc"
                is CalibrationStepState.NotAKeyDisc -> "NotAKeyDisc:${state.discTitle ?: ""}|||${state.attemptedUrl ?: ""}"
                is CalibrationStepState.KeyDiscConfirmed -> "KeyDiscConfirmed:${state.discTitle ?: ""}"
                is CalibrationStepState.Scanning -> "Scanning:${state.progress}|||${state.phase}"
                is CalibrationStepState.Success -> "Success"
                is CalibrationStepState.Error -> "Error:${state.message}|||${state.attemptedUrl ?: ""}"
            }
        }
    },
    restore = { savedList ->
        val stateList = mutableStateListOf<CalibrationStepState>()
        savedList.forEach { savedString ->
            stateList.add(
                when {
                    savedString == "WaitingForDisc" -> CalibrationStepState.WaitingForDisc
                    savedString == "CheckingDisc" -> CalibrationStepState.CheckingDisc
                    savedString.startsWith("NotAKeyDisc:") -> {
                        val parts = savedString.substringAfter("NotAKeyDisc:").split("|||", limit = 2)
                        CalibrationStepState.NotAKeyDisc(
                            discTitle = parts.getOrNull(0)?.takeIf { it.isNotEmpty() },
                            attemptedUrl = parts.getOrNull(1)?.takeIf { it.isNotEmpty() }
                        )
                    }
                    savedString.startsWith("KeyDiscConfirmed:") -> CalibrationStepState.KeyDiscConfirmed(savedString.substringAfter("KeyDiscConfirmed:").takeIf { it.isNotEmpty() })
                    savedString.startsWith("Scanning:") -> {
                        val parts = savedString.substringAfter("Scanning:").split("|||", limit = 2)
                        CalibrationStepState.Scanning(
                            progress = parts.getOrNull(0)?.toFloatOrNull() ?: 0f,
                            phase = parts.getOrElse(1) { "" }
                        )
                    }
                    savedString == "Scanning" -> CalibrationStepState.Scanning(0f, "Scanning disc...")
                    savedString == "Success" -> CalibrationStepState.Success
                    savedString.startsWith("Error:") -> {
                        val parts = savedString.substringAfter("Error:").split("|||", limit = 2)
                        CalibrationStepState.Error(
                            message = parts.getOrElse(0) { "" },
                            attemptedUrl = parts.getOrNull(1)?.takeIf { it.isNotEmpty() },
                            debugInfo = null
                        )
                    }
                    else -> CalibrationStepState.WaitingForDisc
                }
            )
        }
        stateList
    }
)

@Composable
fun CalibrationStepContent(
    stepNumber: Int,
    state: CalibrationStepState,
    onStateChanged: (CalibrationStepState) -> Unit
) {
    // Note: the delayed state change is moved to the ViewModel where scanning will occur

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when (state) {
            is CalibrationStepState.WaitingForDisc -> {
                Text(
                    text = "Insert disc $stepNumber of 3",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
                // "Start Scan" will appear when it transitions to KeyDiscConfirmed
            }
            is CalibrationStepState.CheckingDisc -> {
                CircularProgressIndicator(modifier = Modifier.padding(bottom = 24.dp))
                Text(
                    text = "Checking disc…",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            is CalibrationStepState.NotAKeyDisc -> {
                val uriHandler = LocalUriHandler.current
                Icon(
                    imageVector = Icons.Outlined.Warning,
                    contentDescription = "Warning",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier
                        .size(64.dp)
                        .padding(bottom = 16.dp)
                )
                if (state.discTitle != null) {
                    Text(
                        text = state.discTitle,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                Text(
                    text = "This disc isn't in the AccurateRip database. Please insert a different disc.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = if (state.attemptedUrl != null) 8.dp else 24.dp)
                )
                if (state.attemptedUrl != null) {
                    Text(
                        text = state.attemptedUrl,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        textDecoration = TextDecoration.Underline,
                        modifier = Modifier
                            .padding(bottom = 24.dp, start = 16.dp, end = 16.dp)
                            .clickable {
                                try {
                                    uriHandler.openUri(state.attemptedUrl)
                                } catch (e: Exception) {
                                    // Ignore if no handler available
                                }
                            }
                    )
                }
                Button(onClick = { onStateChanged(CalibrationStepState.WaitingForDisc) }) {
                    Text("Retry")
                }
            }
            is CalibrationStepState.KeyDiscConfirmed -> {
                Icon(
                    imageVector = Icons.Outlined.CheckCircle,
                    contentDescription = "Key Disc Confirmed",
                    tint = Color(0xFF4CAF50),
                    modifier = Modifier
                        .size(64.dp)
                        .padding(bottom = 16.dp)
                )
                if (state.discTitle != null) {
                    Text(
                        text = state.discTitle,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )
                } else {
                    Text(
                        text = "Key Disc Confirmed",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )
                }
            }
            is CalibrationStepState.Scanning -> {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(bottom = 24.dp)) {
                    CircularProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier.size(80.dp),
                        strokeWidth = 6.dp
                    )
                    Text(
                        text = "${(state.progress * 100).toInt()}%",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Text(
                    text = state.phase,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            is CalibrationStepState.Success -> {
                Icon(
                    imageVector = Icons.Outlined.CheckCircle,
                    contentDescription = "Success",
                    tint = Color(0xFF4CAF50),
                    modifier = Modifier
                        .size(64.dp)
                        .padding(bottom = 16.dp)
                )
                Text(
                    text = "Disc scanned successfully",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            is CalibrationStepState.Error -> {
                val uriHandler = LocalUriHandler.current
                Icon(
                    imageVector = Icons.Outlined.Warning,
                    contentDescription = "Error",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier
                        .size(64.dp)
                        .padding(bottom = 16.dp)
                )
                Text(
                    text = state.message,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = if (state.attemptedUrl != null) 8.dp else 24.dp)
                )
                if (state.attemptedUrl != null) {
                    Text(
                        text = state.attemptedUrl,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        textDecoration = TextDecoration.Underline,
                        modifier = Modifier
                            .padding(bottom = 24.dp, start = 16.dp, end = 16.dp)
                            .clickable {
                                try {
                                    uriHandler.openUri(state.attemptedUrl)
                                } catch (e: Exception) {
                                    // Ignore
                                }
                            }
                    )
                }
                Button(onClick = { onStateChanged(CalibrationStepState.WaitingForDisc) }) {
                    Text("Retry")
                }

                if (state.debugInfo != null) {
                    var showDebugSheet by remember { mutableStateOf(false) }

                    TextButton(onClick = { showDebugSheet = true }) {
                        Text("Debug")
                    }

                    if (showDebugSheet) {
                        val info = state.debugInfo
                        @OptIn(ExperimentalMaterial3Api::class)
                        ModalBottomSheet(onDismissRequest = { showDebugSheet = false }) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                val context = LocalContext.current
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Calibration Diagnostics", style = MaterialTheme.typography.titleMedium)
                                    IconButton(onClick = {
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, info.toShareableText())
                                            type = "text/plain"
                                        }
                                        val shareIntent = Intent.createChooser(sendIntent, null)
                                        context.startActivity(shareIntent)
                                    }) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "Share Diagnostics"
                                        )
                                    }
                                }

                                DebugSection("Disc") {
                                    DebugRow("AccurateRip URL", info.discId)
                                }
                                DebugSection("Read Geometry") {
                                    DebugRow("Track scanned",    "${info.trackUsed}")
                                    DebugRow("AR track number",  "${info.arTrackNumber}")
                                    DebugRow("nativeTrackStart", "${info.nativeTrackStart}")
                                    DebugRow("normalisedReadStart", "${info.normalisedReadStart}")
                                    DebugRow("physicalReadStartLba", "${info.physicalReadStartLba}")
                                    DebugRow("actualPreSectors", "${info.actualPreSectors}")
                                    DebugRow("sectorsToRead",    "${info.sectorsToRead}")
                                    DebugRow("totalSectors",     "${info.totalSectors}")
                                }
                                DebugSection("Expected AR Checksums (${info.expectedChecksums.size})") {
                                    info.expectedChecksums.forEach { DebugRow("", it) }
                                }
                                DebugSection("Computed Checksums (sampled every 100 offsets)") {
                                    info.sampledComputedChecksums.forEach { DebugRow("", it) }
                                }
                                Spacer(modifier = Modifier.height(32.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SessionDebugSheet(
    report: List<CalibrationStepReport>,
    finalOffset: Int,
    passed: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val shareText = remember(report) {
        buildString {
            appendLine("BitPerfect Calibration Session Report")
            appendLine("======================================")
            appendLine("Result: ${if (passed) "PASS" else "FAIL (low confidence)"}")
            val sign = if (finalOffset >= 0) "+" else ""
            appendLine("Final offset: $sign$finalOffset samples")
            appendLine()
            report.forEach { step ->
                appendLine(step.toShareableText())
                appendLine()
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header row with title and share button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Session Report",
                    style = MaterialTheme.typography.titleMedium
                )
                IconButton(onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE)
                            as android.content.ClipboardManager
                    clipboard.setPrimaryClip(
                        android.content.ClipData.newPlainText("Calibration Report", shareText)
                    )
                }) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = "Copy to clipboard"
                    )
                }
            }

            // Summary section
            DebugSection("Summary") {
                DebugRow("Result", if (passed) "PASS" else "FAIL")
                val sign = if (finalOffset >= 0) "+" else ""
                DebugRow("Final offset", "$sign$finalOffset samples")
                DebugRow("Steps completed", "${report.size} of 3")

                val allSets = report.map { it.matchingOffsets }
                if (allSets.size == 3) {
                    val intersection = allSets[0].intersect(allSets[1]).intersect(allSets[2])
                    DebugRow(
                        "Intersection",
                        if (intersection.isEmpty()) "empty (no consensus)"
                        else intersection.sorted()
                            .joinToString(", ") { "${if (it >= 0) "+" else ""}$it" }
                    )
                }
            }

            // Per-step sections
            report.forEach { step ->
                DebugSection("Step ${step.stepNumber}") {
                    DebugRow("Disc", step.discId)
                    DebugRow(
                        "Matching offsets",
                        if (step.matchingOffsets.isEmpty()) "none"
                        else step.matchingOffsets.sorted()
                            .joinToString(", ") { "${if (it >= 0) "+" else ""}$it" }
                    )
                    val info = step.debugInfo
                    if (info != null) {
                        DebugRow("Track scanned",        "${info.trackUsed}")
                        DebugRow("AR track number",      "${info.arTrackNumber}")
                        DebugRow("nativeTrackStart",     "${info.nativeTrackStart}")
                        DebugRow("normalisedReadStart",  "${info.normalisedReadStart}")
                        DebugRow("physicalReadStartLba", "${info.physicalReadStartLba}")
                        DebugRow("actualPreSectors",     "${info.actualPreSectors}")
                        DebugRow("sectorsToRead",        "${info.sectorsToRead}")
                        DebugRow("totalSectors",         "${info.totalSectors}")

                        if (info.expectedChecksums.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Expected AR Checksums (${info.expectedChecksums.size})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            info.expectedChecksums.forEach { DebugRow("", it) }
                        }

                        if (info.sampledComputedChecksums.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Computed Checksums (sampled every 100 offsets)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            info.sampledComputedChecksums.forEach { DebugRow("", it) }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OffsetCalibrationScreen(
    driveOffsetRepository: DriveOffsetRepository,
    onNavigateBack: () -> Unit,
    viewModel: OffsetCalibrationViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return OffsetCalibrationViewModel(
                    driveOffsetRepository = driveOffsetRepository
                ) as T
            }
        }
    )
) {
    val uiState by viewModel.uiState.collectAsState()
    val currentStep = uiState.activeStepIndex + 1
    val stepStates = uiState.steps
    val calibrationResult = uiState.calibrationResult
    val saveState = uiState.saveState

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(saveState) {
        when (saveState) {
            is SaveState.Finished -> {
                onNavigateBack()
            }
            is SaveState.Error -> {
                snackbarHostState.showSnackbar(saveState.message)
                viewModel.resetSaveState()
            }
            else -> {}
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = { Text("Calibrate Drive Offset") },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close"
                            )
                        }
                    }
                )
            },
            bottomBar = {
            BottomAppBar {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (calibrationResult != null) {
                        Spacer(modifier = Modifier.weight(1f))
                        Button(
                            onClick = { viewModel.saveOffset(calibrationResult.offset) },
                            enabled = saveState !is SaveState.Saving
                        ) {
                            if (saveState is SaveState.Saving) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp).padding(end = 8.dp),
                                    strokeWidth = 2.dp
                                )
                            }
                            Text("Finish")
                        }
                    } else {
                        if (currentStep > 1) {
                            TextButton(onClick = { viewModel.setActiveStepIndex(currentStep - 2) }) {
                                Text("Back")
                            }
                        } else {
                            Spacer(modifier = Modifier.width(64.dp))
                        }

                        Button(
                            onClick = {
                                if (currentStep < 3) {
                                    viewModel.setActiveStepIndex(currentStep)
                                } else {
                                    onNavigateBack()
                                }
                            },
                            enabled = stepStates[currentStep - 1] is CalibrationStepState.Success
                        ) {
                            Text(if (currentStep < 3) "Next" else "Finish")
                        }
                    }
                }
            }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
            if (calibrationResult != null) {
                // Summary Screen
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (calibrationResult.passed) {
                        Icon(
                            imageVector = Icons.Outlined.CheckCircle,
                            contentDescription = "Passed",
                            tint = Color(0xFF4CAF50),
                            modifier = Modifier.size(80.dp).padding(bottom = 16.dp)
                        )
                        Text(
                            text = "Confidence: Pass",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(bottom = 24.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.Warning,
                            contentDescription = "Warning",
                            tint = Color(0xFFFFC107),
                            modifier = Modifier.size(80.dp).padding(bottom = 16.dp)
                        )
                        Text(
                            text = "Confidence: Low — consider re-running",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(bottom = 24.dp)
                        )
                    }

                    Text(
                        text = "Offset: ${if (calibrationResult.offset > 0) "+" else ""}${calibrationResult.offset} samples",
                        style = MaterialTheme.typography.headlineMedium
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    if (uiState.sessionReport.isNotEmpty()) {
                        var showSessionDebug by remember { mutableStateOf(false) }

                        TextButton(onClick = { showSessionDebug = true }) {
                            Text("Debug")
                        }

                        if (showSessionDebug) {
                            SessionDebugSheet(
                                report      = uiState.sessionReport,
                                finalOffset = calibrationResult.offset,
                                passed      = calibrationResult.passed,
                                onDismiss   = { showSessionDebug = false }
                            )
                        }
                    }
                }
            } else {
                // Step indicator
                Text(
                    text = "Step $currentStep of 3",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(16.dp)
                )

                // Content area
                AnimatedContent(
                    targetState = currentStep,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                                slideOutHorizontally { width -> -width } + fadeOut()
                            )
                        } else {
                            (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
                                slideOutHorizontally { width -> width } + fadeOut()
                            )
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { targetStep ->
                    CalibrationStepContent(
                        stepNumber = targetStep,
                        state = stepStates[targetStep - 1],
                        onStateChanged = { newState ->
                            if (newState is CalibrationStepState.WaitingForDisc) {
                                viewModel.resetStep(targetStep - 1)
                            }
                        }
                    )
                    }
                }
            }
        }
    }
}

@Composable
private fun DebugSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
    Column(content = content)
    HorizontalDivider()
}

@Composable
private fun DebugRow(label: String, value: String) {
    if (label.isEmpty()) {
        Text(value, style = MaterialTheme.typography.bodySmall,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            modifier = Modifier.padding(vertical = 2.dp))
    } else {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodySmall,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        }
    }
}

package com.bitperfect.app.usb

import android.content.Context
import android.hardware.usb.UsbEndpoint
import kotlinx.coroutines.flow.StateFlow
import com.bitperfect.plugin.usbdac.UsbDacState
import com.bitperfect.plugin.usbdac.UsbAudioDacDetector

object DeviceStateManager {
    private var usbDriveDetector: UsbDriveDetector? = null
    private var usbAudioDacDetector: UsbAudioDacDetector? = null

    lateinit var driveStatus: StateFlow<DriveStatus>
        private set

    lateinit var dacState: StateFlow<UsbDacState>
        private set

    fun initialize(context: Context) {
        if (usbDriveDetector == null) {
            val detector = UsbDriveDetector(context.applicationContext)
            usbDriveDetector = detector
            driveStatus = detector.driveStatus

            val dacDetector = UsbAudioDacDetector(context.applicationContext)
            usbAudioDacDetector = dacDetector
            dacState = dacDetector.state
        }
    }

    fun rescan() {
        usbDriveDetector?.scanForDevices()
    }

    fun reportError(message: String) {
        usbDriveDetector?.reportError(message)
    }

    fun pausePolling() {
        usbDriveDetector?.pausePolling()
    }

    fun resumePolling() {
        usbDriveDetector?.resumePolling()
    }

    fun ejectDrive(): Boolean {
        val transport = getTransport() ?: return false
        val outEndpoint = getOutEndpoint() ?: return false
        val inEndpoint = getInEndpoint() ?: return false
        usbDriveDetector?.setEjectingState()
        pausePolling()
        var result = false
        try {
            result = EjectCommand(transport, outEndpoint, inEndpoint).execute()
        } finally {
            resumePolling()
        }
        return result
    }

    fun getTransport(): UsbTransport? = usbDriveDetector?.transport
    fun getInEndpoint(): UsbEndpoint? = usbDriveDetector?.inEndpoint
    fun getOutEndpoint(): UsbEndpoint? = usbDriveDetector?.outEndpoint
}

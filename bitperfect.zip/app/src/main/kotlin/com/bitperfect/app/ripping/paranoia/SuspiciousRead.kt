package com.bitperfect.app.ripping.paranoia
import com.bitperfect.app.ripping.paranoia.cache.CacheProbeResult

data class SuspiciousRead(
    val startLba: Int,
    val endLba: Int,
    val recoveryWindowStartLba: Int?,
    val recoveryWindowEndLba: Int?,
    val strategy: String?,
    val rereadAttempts: Int,
    val recovered: Boolean,
    val driftEvent: DriftEvent? = null,
    val cacheProbeResult: CacheProbeResult? = null
)

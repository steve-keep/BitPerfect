package com.bitperfect.app.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import com.bitperfect.core.utils.AppLogger
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer

class UsbDriveDetector(
    private val context: Context,
    private val transportFactory: ((android.hardware.usb.UsbDeviceConnection) -> UsbTransport)? = null
) {
    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    private val _driveStatus = MutableStateFlow<DriveStatus>(DriveStatus.NoDrive)
    val driveStatus: StateFlow<DriveStatus> = _driveStatus.asStateFlow()

    private var usbConnection: android.hardware.usb.UsbDeviceConnection? = null
    private var massStorageInterface: UsbInterface? = null
    var transport: UsbTransport? = null
    var inEndpoint: UsbEndpoint? = null
    var outEndpoint: UsbEndpoint? = null

    private var targetVendorId: Int? = null
    private var targetProductId: Int? = null

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var pollingJob: Job? = null

    private val ACTION_USB_PERMISSION = "com.bitperfect.app.USB_PERMISSION"

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_USB_PERMISSION -> {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        device?.let { scope.launch { interrogateDevice(it) } }
                    } else {
                        AppLogger.d(TAG, "permission denied for device $device")
                        _driveStatus.value = DriveStatus.PermissionDenied
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    device?.let { checkAndRequestPermission(it) }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    if (device != null) {
                        // For simplicity, just clearing if any device detached.
                        _driveStatus.value = DriveStatus.NoDrive
                        pollingJob?.cancel()
                        cleanupConnection()
                    }
                }
            }
        }
    }

    init {
        val filter = IntentFilter(ACTION_USB_PERMISSION).apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(
            context,
            usbReceiver,
            filter,
            ContextCompat.RECEIVER_EXPORTED
        )

        // Scan for existing devices on startup
        scanForDevices()
    }

    fun reportError(message: String) {
        val currentInfo = _driveStatus.value.info
        _driveStatus.value = DriveStatus.Error(message, currentInfo)
    }

    fun scanForDevices() {
        _driveStatus.value = DriveStatus.NoDrive
        val deviceList = usbManager.deviceList
        for (device in deviceList.values) {
            if (isMassStorageDevice(device)) {
                checkAndRequestPermission(device)
                return
            }
        }
    }

    fun destroy() {
        context.unregisterReceiver(usbReceiver)
        pollingJob?.cancel()
        cleanupConnection()
    }

    private fun cleanupConnection() {
        try {
            massStorageInterface?.let { usbConnection?.releaseInterface(it) }
            usbConnection?.close()
        } catch (e: Exception) {
            AppLogger.e(TAG, "Error cleaning up USB connection", e)
        } finally {
            usbConnection = null
            massStorageInterface = null
            transport = null
            inEndpoint = null
            outEndpoint = null
        }
    }

    private fun isMassStorageDevice(device: UsbDevice): Boolean {
        for (i in 0 until device.interfaceCount) {
            val usbInterface = device.getInterface(i)
            // Class 8 (Mass Storage), Subclass 2 (ATAPI) or 6 (SCSI)
            if (usbInterface.interfaceClass == 8 &&
                (usbInterface.interfaceSubclass == 2 || usbInterface.interfaceSubclass == 6)) {
                return true
            }
        }
        return false
    }

    private fun checkAndRequestPermission(device: UsbDevice) {
        if (!isMassStorageDevice(device)) return

        if (usbManager.hasPermission(device)) {
            scope.launch { interrogateDevice(device) }
        } else {
            _driveStatus.value = DriveStatus.Connecting()
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val permissionIntent = PendingIntent.getBroadcast(
            context, 0, Intent(ACTION_USB_PERMISSION).apply {
                `package` = context.packageName
            }, flags
            )
            usbManager.requestPermission(device, permissionIntent)
        }
    }

    private suspend fun interrogateDevice(device: UsbDevice) {
        pollingJob?.cancel()
        pollingJob = null
        cleanupConnection()

        _driveStatus.value = DriveStatus.Connecting()
        var massStorageInterface: UsbInterface? = null
        var inEndpoint: UsbEndpoint? = null
        var outEndpoint: UsbEndpoint? = null

        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass == 8 && (intf.interfaceSubclass == 2 || intf.interfaceSubclass == 6)) {
                massStorageInterface = intf
                for (j in 0 until intf.endpointCount) {
                    val ep = intf.getEndpoint(j)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) {
                            inEndpoint = ep
                        } else if (ep.direction == UsbConstants.USB_DIR_OUT) {
                            outEndpoint = ep
                        }
                    }
                }
                break
            }
        }

        if (massStorageInterface == null || inEndpoint == null || outEndpoint == null) {
            AppLogger.e(TAG, "Could not find mass storage interface or endpoints")
            _driveStatus.value = DriveStatus.Error("Could not find mass storage endpoints")
            return
        }

        targetVendorId = device.vendorId
        targetProductId = device.productId

        val connection = usbManager.openDevice(device)
        if (connection == null) {
            AppLogger.e(TAG, "Could not open connection")
            _driveStatus.value = DriveStatus.Error("Could not open device")
            return
        }

        if (!connection.claimInterface(massStorageInterface, true)) {
            AppLogger.e(TAG, "Could not claim interface")
            _driveStatus.value = DriveStatus.Error("Could not open device")
            connection.close()
            return
        }

        // Prevent USB selective suspend when screen goes off.
        // setConfiguration() is available from API 21 (minSdk is 28 so no version guard needed).
        // Non-fatal if the OEM rejects it — rip continues but may be less resilient.
        try {
            connection.setConfiguration(device.getConfiguration(0))
            AppLogger.d(TAG, "USB configuration set to prevent selective suspend")
        } catch (e: Exception) {
            AppLogger.w(TAG, "Could not set USB configuration (selective suspend prevention): ${e.message}")
        }

        // Keep local references that will be assigned to class properties
        val transportLocal = transportFactory?.invoke(connection) ?: DefaultUsbTransport(connection)

        this.usbConnection = connection
        this.massStorageInterface = massStorageInterface
        this.transport = transportLocal
        this.inEndpoint = inEndpoint
        this.outEndpoint = outEndpoint

        try {
            val inquiryCommand = ScsiInquiryCommand(transportLocal, outEndpoint, inEndpoint)

            var baseInfo: DriveInfo? = null
            for (attempt in 1..5) {
                baseInfo = inquiryCommand.execute()
                if (baseInfo != null) break
                if (attempt < 5) {
                    AppLogger.w(TAG, "INQUIRY command failed on attempt $attempt, retrying...")
                    delay(500)
                }
            }

            if (baseInfo == null) {
                AppLogger.e(TAG, "INQUIRY command failed after all retries")
                _driveStatus.value = DriveStatus.Error("INQUIRY command failed")
                cleanupConnection()
                return
            }

            if (!baseInfo.isOptical) {
                _driveStatus.value = DriveStatus.NotOptical
                cleanupConnection()
                return
            }

            val info = baseInfo.copy(
                vendorId = device.vendorId,
                productId = device.productId,
                devicePath = device.deviceName
            )

            // Single TUR during interrogation — just establish initial state.
            // The polling loop handles spin-up → DiscReady from here.
            val cbwTag = 1
            val turResult = executeSingleTestUnitReady(transportLocal, outEndpoint, inEndpoint, cbwTag)
            when (turResult) {
                TurResult.READY -> {
                    val tocResult = readTocWithRetry(transportLocal, outEndpoint, inEndpoint)
                    if (tocResult != null) {
                        _driveStatus.value = DriveStatus.DiscReady(info, tocResult.first, tocResult.second)
                    } else {
                        _driveStatus.value = DriveStatus.Error("Failed to read disc layout", info)
                    }
                }
                TurResult.SPINNING_UP -> {
                    _driveStatus.value = DriveStatus.SpinningUp(info)
                }
                TurResult.TRAY_OPEN -> {
                    _driveStatus.value = DriveStatus.Open(info)
                }
                TurResult.NOT_READY -> {
                    _driveStatus.value = DriveStatus.Empty(info)
                }
                TurResult.CONNECTION_DEAD -> {
                    AppLogger.w(TAG, "Interrogation: USB connection dead")
                    _driveStatus.value = DriveStatus.Error("USB connection dead during interrogation", info)
                    cleanupConnection()
                    return
                }
            }

            // Start polling loop which takes ownership of cleaning up the connection
            startPollingLoop(info)

        } catch (e: Exception) {
            AppLogger.e(TAG, "Error interrogating device", e)
            val currentInfo = _driveStatus.value.info
            _driveStatus.value = DriveStatus.Error(e.message ?: "Unknown error", currentInfo)
            cleanupConnection()
        }
    }

    enum class TurResult {
        READY, SPINNING_UP, NOT_READY, TRAY_OPEN, CONNECTION_DEAD
    }

    enum class SenseResult {
        SPINNING_UP, TRAY_OPEN, NOT_READY
    }

    fun pausePolling() {
        pollingJob?.cancel()
        pollingJob = null
    }

    fun resumePolling() {
        val currentStatus = _driveStatus.value
        val info = currentStatus.info ?: return
        // Only restart if we have a connected drive
        startPollingLoop(info)
    }

    fun setEjectingState() {
        val currentStatus = _driveStatus.value
        val info = currentStatus.info ?: return
        _driveStatus.value = DriveStatus.Ejecting(info)
    }

    private fun startPollingLoop(info: DriveInfo) {
        pollingJob?.cancel()
        pollingJob = scope.launch {
            try {
                var cbwTag = 100 // Start from a reasonably high tag to avoid overlap with interrogate
                while (isActive) {
                    val pollInterval = when (_driveStatus.value) {
                        is DriveStatus.SpinningUp    -> 500L
                        is DriveStatus.DetectingDisc -> 250L
                        else                         -> 2000L
                    }
                    delay(pollInterval)

                    val currentTransport = transport
                    val currentOutEndpoint = outEndpoint
                    val currentInEndpoint = inEndpoint

                    if (currentTransport == null || currentOutEndpoint == null || currentInEndpoint == null) {
                        break
                    }

                    val turResult = executeSingleTestUnitReady(currentTransport, currentOutEndpoint, currentInEndpoint, cbwTag)
                    cbwTag += 2

                    val currentStatus = _driveStatus.value
                    when (turResult) {
                        TurResult.READY -> {
                            if (currentStatus !is DriveStatus.DiscReady) {
                                val tocResult = readTocWithRetry(currentTransport, currentOutEndpoint, currentInEndpoint)
                                if (tocResult != null) {
                                    _driveStatus.value = DriveStatus.DiscReady(info, tocResult.first, tocResult.second)
                                } else {
                                    _driveStatus.value = DriveStatus.Error("Failed to read disc layout", info)
                                }
                            }
                        }
                        TurResult.SPINNING_UP -> {
                            if (currentStatus !is DriveStatus.SpinningUp) {
                                _driveStatus.value = DriveStatus.SpinningUp(info)
                            }
                        }
                        TurResult.TRAY_OPEN -> {
                            if (currentStatus !is DriveStatus.Open) {
                                _driveStatus.value = DriveStatus.Open(info)
                            }
                        }
                        TurResult.NOT_READY -> {
                            when (currentStatus) {
                                is DriveStatus.SpinningUp, is DriveStatus.DetectingDisc -> {
                                    // Drive has finished mechanical spin-up but is not yet ready to read.
                                    // Hold in DetectingDisc and keep fast-polling at 250 ms rather than
                                    // dropping to Empty.
                                    if (currentStatus !is DriveStatus.DetectingDisc) {
                                        _driveStatus.value = DriveStatus.DetectingDisc(info)
                                    }
                                }
                                else -> {
                                    if (currentStatus !is DriveStatus.Empty) {
                                        _driveStatus.value = DriveStatus.Empty(info)
                                    }
                                }
                            }
                        }
                        TurResult.CONNECTION_DEAD -> {
                            AppLogger.w(TAG, "USB connection dead, attempting silent reconnect")
                            cleanupConnection()
                            _driveStatus.value = DriveStatus.Connecting()
                            scope.launch {
                                delay(500)
                                reconnectWithoutPermissionRequest()
                            }
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                AppLogger.e(TAG, "Error in polling loop", e)
            }
        }
    }

    private fun reconnectWithoutPermissionRequest() {
        scope.launch {
            repeat(5) { attempt ->
                delay(500L * (attempt + 1)) // 500ms, 1s, 1.5s, 2s, 2.5s backoff
                val device = usbManager.deviceList.values.firstOrNull {
                    usbManager.hasPermission(it) &&
                    isMassStorageDevice(it) &&
                    it.vendorId == targetVendorId &&
                    it.productId == targetProductId
                }
                if (device != null) {
                    interrogateDevice(device)
                    return@launch
                }
                AppLogger.w(TAG, "Reconnect attempt ${attempt + 1}: no device with permission yet")
            }
            // All retries failed - surface the error
            AppLogger.e(TAG, "Could not reconnect after 5 attempts")
            _driveStatus.value = DriveStatus.Error("USB reconnect failed — device lost in background")
            scanForDevices()
        }
    }

    private fun executeSingleTestUnitReady(transport: UsbTransport, outEndpoint: UsbEndpoint, inEndpoint: UsbEndpoint, tag: Int): TurResult {
        // CBW: 31 bytes
        val cbw = ByteArray(31)
        val buffer = ByteBuffer.wrap(cbw).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        buffer.putInt(0x43425355) // dCBWSignature
        buffer.putInt(tag)        // dCBWTag (can be anything unique)
        buffer.putInt(0)          // dCBWDataTransferLength (TUR has no data phase)
        buffer.put(0x00.toByte()) // bmCBWFlags: 0x00 for OUT / no data
        buffer.put(0)             // bCBWLUN
        buffer.put(6)             // bCBWCBLength

        // SCSI TEST UNIT READY Command Block (6 bytes)
        buffer.put(0x00)          // Opcode: TEST UNIT READY
        buffer.put(0)
        buffer.put(0)
        buffer.put(0)
        buffer.put(0)
        buffer.put(0)

        // Send CBW
        var transferred = transport.bulkTransfer(outEndpoint, cbw, cbw.size, 15000)
        if (transferred < 0) {
            AppLogger.e(TAG, "TUR: Failed to send CBW — timeout, returning NOT_READY")
            return TurResult.NOT_READY
        }

        // No Data phase for TUR

        // Read CSW (Command Status Wrapper)
        val csw = ByteArray(13)
        transferred = transport.bulkTransfer(inEndpoint, csw, csw.size, 15000)
        if (transferred < 0) {
            AppLogger.e(TAG, "TUR: Failed to read CSW — timeout, returning NOT_READY")
            return TurResult.NOT_READY
        }

        // Validate CSW
        val cswBuffer = ByteBuffer.wrap(csw).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        val cswSignature = cswBuffer.getInt(0)
        if (cswSignature != 0x53425355) {
            AppLogger.e(TAG, "TUR: Invalid CSW signature on tag $tag")
            return TurResult.NOT_READY
        }
        val status = csw[12]
        if (status != 0.toByte()) {
            AppLogger.d(TAG, "TUR: Drive not ready (status=$status) on tag $tag")
            val senseResult = executeRequestSense(transport, outEndpoint, inEndpoint, tag + 1)
            return when (senseResult) {
                SenseResult.SPINNING_UP -> TurResult.SPINNING_UP
                SenseResult.TRAY_OPEN -> TurResult.TRAY_OPEN
                else -> TurResult.NOT_READY
            }
        }

        return TurResult.READY
    }

    private suspend fun readTocWithRetry(transport: UsbTransport, outEndpoint: UsbEndpoint, inEndpoint: UsbEndpoint): Pair<com.bitperfect.core.models.DiscToc, ByteArray>? {
        val tocCommand = ReadTocCommand(transport, outEndpoint, inEndpoint)
        var tocResult: Pair<com.bitperfect.core.models.DiscToc, ByteArray>? = null
        for (attempt in 1..3) {
            tocResult = tocCommand.execute()
            if (tocResult != null) break
            if (attempt < 3) {
                delay(500)
            }
        }
        if (tocResult == null) {
            AppLogger.w(TAG, "TOC is null after DiscReady")
        }
        return tocResult
    }

    private fun executeRequestSense(transport: UsbTransport, outEndpoint: UsbEndpoint, inEndpoint: UsbEndpoint, tag: Int): SenseResult {
        val cbw = ByteArray(31)
        val buffer = ByteBuffer.wrap(cbw).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        buffer.putInt(0x43425355) // dCBWSignature
        buffer.putInt(tag)        // dCBWTag
        buffer.putInt(18)         // dCBWDataTransferLength (18 bytes for Request Sense)
        buffer.put(0x80.toByte()) // bmCBWFlags: 0x80 for IN
        buffer.put(0)             // bCBWLUN
        buffer.put(6)             // bCBWCBLength

        // SCSI REQUEST SENSE Command Block (6 bytes)
        buffer.put(0x03)          // Opcode: REQUEST SENSE
        buffer.put(0)
        buffer.put(0)
        buffer.put(0)
        buffer.put(18)            // Allocation length
        buffer.put(0)

        // Send CBW
        var transferred = transport.bulkTransfer(outEndpoint, cbw, cbw.size, 15000)
        if (transferred < 0) return SenseResult.NOT_READY

        // Read Data
        val senseData = ByteArray(18)
        transferred = transport.bulkTransfer(inEndpoint, senseData, senseData.size, 15000)
        if (transferred < 0) return SenseResult.NOT_READY

        // Read CSW
        val csw = ByteArray(13)
        transport.bulkTransfer(inEndpoint, csw, csw.size, 15000)

        val senseKey = senseData[2].toInt() and 0x0F
        val asc = senseData[12].toInt() and 0xFF
        val ascq = senseData[13].toInt() and 0xFF

        if (senseKey == 0x02 && asc == 0x04 && ascq == 0x01) {
            return SenseResult.SPINNING_UP
        } else if (senseKey == 0x02 && asc == 0x3A && ascq == 0x02) {
            return SenseResult.TRAY_OPEN
        }

        return SenseResult.NOT_READY
    }

    companion object {
        private const val TAG = "UsbDriveDetector"
    }
}

data class DriveInfo(
    val vendor: String,
    val model: String,
    val firmware: String? = null,
    val isOptical: Boolean,
    val vendorId: Int? = null,
    val productId: Int? = null,
    val devicePath: String = ""
) {
    fun driveId(): String {
        return listOfNotNull(vendor, model, firmware)
            .joinToString("_")
            .lowercase()
            .replace(" ", "")
    }
}

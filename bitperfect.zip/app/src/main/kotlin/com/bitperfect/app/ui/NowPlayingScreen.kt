package com.bitperfect.app.ui

import android.content.ContentUris
import android.provider.MediaStore
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.BottomSheetScaffold
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.rememberBottomSheetScaffoldState
import androidx.compose.material3.rememberStandardBottomSheetState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.bitperfect.app.ui.theme.VerificationGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.filled.DragHandle
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import kotlin.math.roundToInt
import androidx.compose.runtime.mutableFloatStateOf
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.remember

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun NowPlayingScreen(
    viewModel: AppViewModel,
    enabled: Boolean,
    isExternalOutput: Boolean,
    onOutputDeviceClick: () -> Unit,
    onCollapse: () -> Unit = {},
    primaryColor: Color = MaterialTheme.colorScheme.primary
) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val positionMs by viewModel.positionMs.collectAsState()
    val lrcLines by viewModel.lrcLines.collectAsState()
    val upNextQueue by viewModel.upNextQueue.collectAsState()
    val currentQueueIndex by viewModel.currentQueueIndex.collectAsState()
    val currentTrackTitle by viewModel.currentTrackTitle.collectAsState()
    val currentTrackArtist by viewModel.currentTrackArtist.collectAsState()
    val currentAlbumTitle by viewModel.currentAlbumTitle.collectAsState()
    val currentAlbumArtUri by viewModel.currentAlbumArtUri.collectAsState()
    val trackFormatInfo by viewModel.trackFormatInfo.collectAsState()

    val currentMediaId by viewModel.currentMediaId.collectAsState()
    val currentTrackState = viewModel.currentTrack.collectAsState()
    val currentTrack = currentTrackState.value

    var showLyrics by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(currentTrackTitle, currentMediaId) {
        showLyrics = false
    }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            viewModel.pollPosition()
            delay(500)
        }
    }

    val bottomSheetScaffoldState = rememberBottomSheetScaffoldState(
        bottomSheetState = rememberStandardBottomSheetState(
            initialValue = SheetValue.Hidden,
            skipHiddenState = false
        )
    )

    BottomSheetScaffold(
        scaffoldState = bottomSheetScaffoldState,
        sheetContent = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.85f)
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = "Up Next",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 16.dp, top = 8.dp)
                )

                val upcomingItems = if (currentQueueIndex + 1 < upNextQueue.size) {
                    upNextQueue.subList(currentQueueIndex + 1, upNextQueue.size)
                } else {
                    emptyList()
                }

                if (upcomingItems.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No upcoming tracks", color = Color.White.copy(alpha = 0.5f))
                    }
                } else {
                    var displayUpcomingItems by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(upcomingItems) }
                    var isDraggingGlobal by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

                    LaunchedEffect(upcomingItems) {
                        if (!isDraggingGlobal) {
                            displayUpcomingItems = upcomingItems
                        }
                    }

                    val lazyListState = rememberLazyListState()
                    var dragStartIndex by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Int?>(null) }
                    var currentDragIndex by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Int?>(null) }

                    val reorderState = rememberReorderableLazyListState(lazyListState) { from, to ->
                        val mutableList = displayUpcomingItems.toMutableList()
                        val item = mutableList.removeAt(from.index)
                        mutableList.add(to.index, item)
                        displayUpcomingItems = mutableList

                        val toActualIndex = to.index + currentQueueIndex + 1
                        currentDragIndex = toActualIndex
                    }

                    val density = LocalDensity.current
                    val scope = androidx.compose.runtime.rememberCoroutineScope()
                    LazyColumn(
                        state = lazyListState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 16.dp)
                    ) {
                        itemsIndexed(displayUpcomingItems, key = { index, item -> "${item.id}_${item.hashCode()}" }) { index, item ->
                            val currentItemIndex by androidx.compose.runtime.rememberUpdatedState(index)
                            val buttonWidthDp = 88.dp
                            val buttonWidthPx = with(density) { buttonWidthDp.toPx() }
                            val offsetX = androidx.compose.runtime.remember { androidx.compose.animation.core.Animatable(0f) }

                            ReorderableItem(reorderState, key = "${item.id}_${item.hashCode()}") { isDragging ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                ) {
                                    // Background Layer (Delete Button)
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.CenterEnd)
                                            .width(buttonWidthDp)
                                            .height(48.dp) // Match Album Art
                                            .background(Color.Red, RoundedCornerShape(8.dp))
                                            .clickable {
                                                val actualIndex = currentItemIndex + currentQueueIndex + 1
                                                viewModel.removeQueueItem(actualIndex)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "Delete",
                                            color = Color.White,
                                            style = MaterialTheme.typography.bodyLarge
                                        )
                                    }

                                    // Foreground Layer
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .graphicsLayer {
                                                translationX = offsetX.value
                                            }
                                            .background(if (isDragging) Color(0xFF2A2A2A) else MaterialTheme.colorScheme.surfaceContainerLow)
                                            .pointerInput(Unit) {
                                                detectHorizontalDragGestures(
                                                    onDragEnd = {
                                                        scope.launch {
                                                            if (offsetX.value < -buttonWidthPx / 2) {
                                                                offsetX.animateTo(-buttonWidthPx, animationSpec = tween(200))
                                                            } else {
                                                                offsetX.animateTo(0f, animationSpec = tween(200))
                                                            }
                                                        }
                                                    },
                                                    onDragCancel = {
                                                        scope.launch {
                                                            offsetX.animateTo(0f, animationSpec = tween(200))
                                                        }
                                                    },
                                                    onHorizontalDrag = { change, dragAmount ->
                                                        change.consume()
                                                        scope.launch {
                                                            val newOffset = (offsetX.value + dragAmount).coerceIn(-buttonWidthPx, 0f)
                                                            offsetX.snapTo(newOffset)
                                                        }
                                                    }
                                                )
                                            }
                                            .clickable {
                                                if (offsetX.value < 0f) {
                                                    scope.launch {
                                                        offsetX.animateTo(0f, animationSpec = tween(200))
                                                    }
                                                }
                                            },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                            val artworkUri = if (item.albumId != -1L)
                                                ContentUris.withAppendedId(android.net.Uri.parse("content://media/external/audio/albumart"), item.albumId)
                                            else null
                                            if (artworkUri != null) {
                                                AsyncImage(
                                                    model = ImageRequest.Builder(LocalContext.current)
                                                        .data(artworkUri)
                                                        .crossfade(true)
                                                        .build(),
                                                    contentDescription = "Album Art",
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .size(48.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                )
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .size(48.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(Color(0xFF141414)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Album,
                                                        contentDescription = "No Album Art",
                                                        modifier = Modifier.size(24.dp),
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = item.title,
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    color = Color.White,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = item.artist,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = Color.White.copy(alpha = 0.5f),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            IconButton(
                                                onClick = {},
                                                modifier = Modifier.draggableHandle(
                                                    onDragStarted = {
                                                        isDraggingGlobal = true
                                                        val actualIndex = currentItemIndex + currentQueueIndex + 1
                                                        dragStartIndex = actualIndex
                                                        currentDragIndex = actualIndex
                                                    },
                                                    onDragStopped = {
                                                        isDraggingGlobal = false
                                                        val start = dragStartIndex
                                                        val end = currentDragIndex
                                                        if (start != null && end != null && start != end) {
                                                            viewModel.commitQueueItemMove(start, end)
                                                        }
                                                        displayUpcomingItems = upcomingItems
                                                        dragStartIndex = null
                                                        currentDragIndex = null
                                                    }
                                                )
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DragHandle,
                                                    contentDescription = "Reorder",
                                                    tint = Color.White.copy(alpha = 0.5f)
                                                )
                                            }
                                        }
                                    }
                            }
                        }
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                TextButton(onClick = { viewModel.clearQueue() }) {
                                    Text(
                                        text = "Clear Queue",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        sheetPeekHeight = 0.dp,
        sheetContainerColor = Color(0xFF1E1E1E),
        containerColor = Color.Transparent
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        top = 24.dp + WindowInsets.statusBars.asPaddingValues().calculateTopPadding(),
                        bottom = 24.dp,
                        start = 24.dp,
                        end = 24.dp
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
            // Top Bar
            Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onCollapse) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = "Collapse",
                    tint = Color.White
                )
            }
            Text(
                text = "Now Playing",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            if (lrcLines.isNotEmpty()) {
                IconButton(onClick = { showLyrics = !showLyrics }) {
                    Icon(
                        imageVector = if (showLyrics) Icons.Default.Image else Icons.Default.MusicNote,
                        contentDescription = if (showLyrics) "Show Artwork" else "Show Lyrics",
                        tint = Color.White
                    )
                }
            } else {
                // Empty box to keep "Now Playing" centered
                Box(modifier = Modifier.size(48.dp))
            }
        }

            val rotation by animateFloatAsState(
                targetValue = if (showLyrics) 180f else 0f,
                animationSpec = tween(500, easing = FastOutSlowInEasing),
                label = "card_flip"
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .graphicsLayer {
                        rotationY = rotation
                        cameraDistance = 12f * density
                    },
                contentAlignment = Alignment.Center
            ) {
                if (rotation <= 90f) {
                    if (currentAlbumArtUri != null) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(currentAlbumArtUri)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Album Art",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(12.dp))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF141414)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Album,
                                contentDescription = "No Album Art",
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    Box(modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(12.dp))
                        .graphicsLayer { rotationY = 180f }) {
                        LyricsCard(
                            lrcLines = lrcLines,
                            positionMs = positionMs,
                            modifier = Modifier.fillMaxSize(),
                            activeColor = primaryColor
                        )
                    }
                }
            }

        Spacer(modifier = Modifier.height(32.dp))

        if (trackFormatInfo != null) {
            Surface(
                shape = CircleShape,
                color = primaryColor,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Text(
                    text = trackFormatInfo!!,
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.Black,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        Text(
            text = currentTrackTitle ?: "Unknown Track",
            style = MaterialTheme.typography.headlineSmall,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        val artistName = currentTrackArtist ?: "Unknown Artist"
        val albumTitle = currentAlbumTitle ?: "Unknown Album"
        Text(
            text = "$artistName · $albumTitle",
            style = MaterialTheme.typography.bodyLarge,
            color = primaryColor, // Dynamic or fallback color
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(32.dp))

        val durationMs = currentTrack?.durationMs ?: 0L
        val currentPosition = positionMs.coerceAtMost(durationMs)
        val remainingMs = durationMs - currentPosition

        val interactionSource = androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() }

        androidx.compose.material3.Slider(
            value = currentPosition.toFloat(),
            valueRange = 0f..(durationMs.toFloat().coerceAtLeast(1f)),
            onValueChange = { viewModel.seekTo(it.toLong()) },
            modifier = Modifier.fillMaxWidth(),
            interactionSource = interactionSource,
            colors = androidx.compose.material3.SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.White,
                inactiveTrackColor = Color.White.copy(alpha = 0.3f)
            ),
            thumb = {
                androidx.compose.material3.SliderDefaults.Thumb(
                    interactionSource = interactionSource,
                    modifier = Modifier.size(12.dp),
                    colors = androidx.compose.material3.SliderDefaults.colors(
                        thumbColor = Color.White
                    )
                )
            },
            track = { sliderState ->
                androidx.compose.material3.SliderDefaults.Track(
                    sliderState = sliderState,
                    modifier = Modifier.height(2.dp),
                    colors = androidx.compose.material3.SliderDefaults.colors(
                        activeTrackColor = Color.White,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                    )
                )
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatTimeMs(currentPosition),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "-${formatTimeMs(remainingMs)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.skipPrev() },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SkipPrevious,
                    contentDescription = "Previous",
                    modifier = Modifier.size(32.dp),
                    tint = Color.White
                )
            }

            Surface(
                onClick = { viewModel.togglePlayPause() },
                modifier = Modifier.size(72.dp),
                shape = CircleShape,
                color = primaryColor, // Dynamic or fallback color
                contentColor = Color.Black
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            IconButton(
                onClick = { viewModel.skipNext() },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Next",
                    modifier = Modifier.size(32.dp),
                    tint = Color.White
                )
            }
            }

            // Bottom Up Next Bar
            Spacer(modifier = Modifier.weight(1f))

            val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onOutputDeviceClick,
                    enabled = enabled,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speaker,
                        contentDescription = "Output Device",
                        tint = if (isExternalOutput) primaryColor else Color.White.copy(alpha = if (enabled) 0.85f else 0.4f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            bottomSheetScaffoldState.bottomSheetState.expand()
                        }
                    },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                        contentDescription = "Queue",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
    }
}

private fun formatTimeMs(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%d:%02d", minutes, seconds)
}

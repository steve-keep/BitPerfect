import re

def dedupe(filepath):
    with open(filepath, 'r') as f:
        c = f.read()

    lines = c.split('\n')
    unique_imports = set()
    new_lines = []

    for line in lines:
        if line.startswith('import '):
            if line not in unique_imports:
                unique_imports.add(line)
                new_lines.append(line)
        else:
            new_lines.append(line)

    with open(filepath, 'w') as f:
        f.write('\n'.join(new_lines))

dedupe('app/src/main/kotlin/com/bitperfect/app/player/PlaybackService.kt')

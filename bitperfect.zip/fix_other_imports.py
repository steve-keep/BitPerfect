import re
files = [
    'app/src/main/kotlin/com/bitperfect/app/usb/DeviceStateManager.kt',
    'app/src/main/kotlin/com/bitperfect/app/ui/AppViewModel.kt',
    'app/src/main/kotlin/com/bitperfect/app/ui/OutputDeviceSheet.kt',
    'app/src/main/kotlin/com/bitperfect/app/MainActivity.kt'
]
for filepath in files:
    with open(filepath, 'r') as f:
        c = f.read()
    c = c.replace('import com.bitperfect.app.usb.UsbDacState', 'import com.bitperfect.plugin.usbdac.UsbDacState')
    c = c.replace('import com.bitperfect.app.usb.UsbAudioDacDetector', 'import com.bitperfect.plugin.usbdac.UsbAudioDacDetector')
    with open(filepath, 'w') as f:
        f.write(c)

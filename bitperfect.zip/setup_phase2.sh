set -e

mkdir -p plugin-usb-dac/libs
mkdir -p plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac
mkdir -p plugin-usb-dac/src/test/kotlin/com/bitperfect/plugin/usbdac

cat << 'GRADLE' > plugin-usb-dac/build.gradle
plugins {
    id 'com.android.library'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.bitperfect.plugin.usbdac'
    compileSdk 36
    defaultConfig {
        minSdk 29
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = '17'
        freeCompilerArgs += ["-Xskip-metadata-version-check"]
    }
    testOptions {
        unitTests {
            includeAndroidResources = true
            returnDefaultValues = true
        }
    }
}

dependencies {
    implementation fileTree(dir: 'libs', include: ['*.aar'])
    implementation project(':core')

    def media3_version = "1.3.1"
    implementation "androidx.media3:media3-exoplayer:\${media3_version}"
    implementation "androidx.media3:media3-common:\${media3_version}"

    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
    implementation 'androidx.core:core-ktx:1.13.1'

    testImplementation 'junit:junit:4.13.2'
    testImplementation "org.mockito:mockito-core:4.8.0"
    testImplementation "org.mockito:mockito-inline:4.8.0"
    testImplementation "io.mockk:mockk:1.13.10"
    testImplementation "org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3"
    testImplementation "org.robolectric:robolectric:4.12.2"
    testImplementation "androidx.test:core-ktx:1.5.0"
}
GRADLE

sed -i "s/include ':app', ':core'/include ':app', ':core', ':plugin-usb-dac'/" settings.gradle
sed -i '/dependencies {/a \    implementation project(":plugin-usb-dac")' app/build.gradle

mv app/libs/decent-usb-audio-driver-0.1.0.aar plugin-usb-dac/libs/
mv app/libs/decent-usb-audio-wrapper-media3-0.1.0.aar plugin-usb-dac/libs/
mv app/src/main/kotlin/com/bitperfect/app/usb/UsbDacState.kt plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac/
mv app/src/main/kotlin/com/bitperfect/app/usb/UsbAudioDacDetector.kt plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac/
mv app/src/main/kotlin/com/bitperfect/app/player/UsbAudioRenderersFactory.kt plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac/
mv app/src/test/kotlin/com/bitperfect/app/usb/UsbAudioDacDetectorTest.kt plugin-usb-dac/src/test/kotlin/com/bitperfect/plugin/usbdac/

sed -i 's/package com.bitperfect.app.usb/package com.bitperfect.plugin.usbdac/' plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac/UsbDacState.kt
sed -i 's/package com.bitperfect.app.usb/package com.bitperfect.plugin.usbdac/' plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac/UsbAudioDacDetector.kt
sed -i 's/package com.bitperfect.app.player/package com.bitperfect.plugin.usbdac/' plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac/UsbAudioRenderersFactory.kt
sed -i 's/package com.bitperfect.app.usb/package com.bitperfect.plugin.usbdac/' plugin-usb-dac/src/test/kotlin/com/bitperfect/plugin/usbdac/UsbAudioDacDetectorTest.kt

cat << 'PROVIDER' > plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac/ExoPlayerProvider.kt
package com.bitperfect.plugin.usbdac

import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.bitperfect.core.output.PlayerProvider

@UnstableApi
internal class ExoPlayerProvider(
    private val exoPlayer: ExoPlayer,
    private val mediaItems: List<MediaItem>,
    private val startIndex: Int,
    private val startPositionMs: Long,
    private val playWhenReady: Boolean,
) : PlayerProvider {

    override val player: ExoPlayer = exoPlayer

    init {
        exoPlayer.setMediaItems(mediaItems, startIndex, startPositionMs)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = playWhenReady
    }

    override fun release() {
        exoPlayer.stop()
        exoPlayer.release()
    }
}
PROVIDER

cat << 'PLUGIN' > plugin-usb-dac/src/main/kotlin/com/bitperfect/plugin/usbdac/UsbDacOutputPlugin.kt
package com.bitperfect.plugin.usbdac

import android.content.Context
import android.content.ContentUris
import android.provider.MediaStore
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import com.bitperfect.core.output.CoreTrackInfo
import com.bitperfect.core.output.OutputDevice
import com.bitperfect.core.output.OutputPlugin
import com.bitperfect.core.output.OutputPluginRegistry
import com.bitperfect.core.output.PlaybackHandoffState
import com.bitperfect.core.output.PlayerProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

@UnstableApi
class UsbDacOutputPlugin(
    private val appContext: Context,
    private val detectorFactory: (Context) -> UsbAudioDacDetector = { ctx -> UsbAudioDacDetector(ctx) }
) : OutputPlugin {

    override val deviceType: String = "usb_dac"

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var detector: UsbAudioDacDetector? = null

    override fun attach(registry: OutputPluginRegistry) {
        val det = detectorFactory(appContext)
        detector = det

        scope.launch {
            det.state.collect { dacState ->
                when (dacState) {
                    is UsbDacState.Connected -> {
                        val device = OutputDevice.UsbDac(
                            device = dacState.device,
                            protocol = dacState.protocol,
                            productName = dacState.productName,
                        )
                        registry.updateDevices(deviceType, listOf(device))
                    }
                    is UsbDacState.Absent,
                    is UsbDacState.PermissionPending -> {
                        registry.updateDevices(deviceType, emptyList())
                    }
                }
            }
        }
    }

    override fun createPlayerProvider(
        context: Context,
        device: OutputDevice,
        handoffState: PlaybackHandoffState,
    ): PlayerProvider {
        val mediaItems = handoffState.tracks.map { it.toMediaItem(context) }
        val exoPlayer = buildExoPlayer(context)
        return ExoPlayerProvider(
            exoPlayer    = exoPlayer,
            mediaItems   = mediaItems,
            startIndex   = handoffState.currentIndex,
            startPositionMs = handoffState.positionMs,
            playWhenReady   = handoffState.playWhenReady,
        )
    }

    override fun release() {
        detector?.destroy()
        detector = null
        scope.cancel()
    }

    private fun buildExoPlayer(context: Context): ExoPlayer {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_500, 3_000)
            .build()

        return ExoPlayer.Builder(context, UsbAudioRenderersFactory(context))
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setLoadControl(loadControl)
            .build()
    }
}

/**
 * Converts a [CoreTrackInfo] into a Media3 [MediaItem] with a MediaStore URI.
 */
private fun CoreTrackInfo.toMediaItem(context: Context): MediaItem {
    val uri = ContentUris.withAppendedId(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id
    )
    val artUri = if (albumId != -1L) {
        ContentUris.withAppendedId(
            android.net.Uri.parse("content://media/external/audio/albumart"), albumId
        )
    } else null

    return MediaItem.Builder()
        .setMediaId("$id")
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(albumTitle)
                .setTrackNumber(trackNumber)
                .setArtworkUri(artUri)
                .build()
        )
        .build()
}
PLUGIN

cat << 'TEST' > plugin-usb-dac/src/test/kotlin/com/bitperfect/plugin/usbdac/UsbDacOutputPluginTest.kt
package com.bitperfect.plugin.usbdac

import android.content.Context
import android.hardware.usb.UsbDevice
import com.bitperfect.core.output.OutputDevice
import com.bitperfect.core.output.OutputPluginRegistry
import com.bitperfect.core.output.UacProtocol
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class UsbDacOutputPluginTest {

    @Test
    fun `deviceType is usb_dac`() {
        val plugin = UsbDacOutputPlugin(mockk(relaxed = true))
        assertEquals("usb_dac", plugin.deviceType)
    }

    @Test
    fun `attach registers connected device with registry`() = runTest(UnconfinedTestDispatcher()) {
        val context = mockk<Context>(relaxed = true)
        val registry = mockk<OutputPluginRegistry>(relaxed = true)
        
        val usbDevice = mockk<UsbDevice>(relaxed = true)
        every { usbDevice.deviceId } returns 42

        val mockDetector = mockk<UsbAudioDacDetector>(relaxed = true)
        val stateFlow = MutableStateFlow<UsbDacState>(
            UsbDacState.Connected(usbDevice, UacProtocol.UAC2, "Test DAC")
        )
        every { mockDetector.state } returns stateFlow

        val plugin = UsbDacOutputPlugin(
            appContext = context,
            detectorFactory = { mockDetector }
        )

        plugin.attach(registry)

        val device = OutputDevice.UsbDac(usbDevice, UacProtocol.UAC2, "Test DAC")
        verify { registry.updateDevices("usb_dac", match { it.size == 1 && it[0] is OutputDevice.UsbDac }) }
    }

    @Test
    fun `attach clears devices when DAC absent`() = runTest(UnconfinedTestDispatcher()) {
        val context = mockk<Context>(relaxed = true)
        val registry = mockk<OutputPluginRegistry>(relaxed = true)

        val mockDetector = mockk<UsbAudioDacDetector>(relaxed = true)
        val stateFlow = MutableStateFlow<UsbDacState>(UsbDacState.Absent)
        every { mockDetector.state } returns stateFlow

        val plugin = UsbDacOutputPlugin(
            appContext = context,
            detectorFactory = { mockDetector }
        )

        plugin.attach(registry)

        verify { registry.updateDevices("usb_dac", emptyList()) }
    }
}
TEST


import os
import re

def fix_file(filepath):
    if not os.path.exists(filepath):
        print(f"Skipping {filepath}, does not exist")
        return
        
    with open(filepath, 'r') as f:
        content = f.read()

    # Deduplicate imports
    imports = re.findall(r'^import .+$', content, re.MULTILINE)
    unique_imports = set()
    
    lines = content.split('\n')
    new_lines = []
    
    for line in lines:
        if line.startswith('import '):
            if line not in unique_imports:
                unique_imports.add(line)
                new_lines.append(line)
        else:
            new_lines.append(line)
            
    content_fixed = '\n'.join(new_lines)
    
    needs_dac_state = 'UsbDacState' in content_fixed and 'import com.bitperfect.plugin.usbdac.UsbDacState' not in content_fixed
    needs_dac_detector = 'UsbAudioDacDetector' in content_fixed and 'import com.bitperfect.plugin.usbdac.UsbAudioDacDetector' not in content_fixed
    needs_plugin = 'UsbDacOutputPlugin' in content_fixed and 'import com.bitperfect.plugin.usbdac.UsbDacOutputPlugin' not in content_fixed
    
    if needs_dac_state or needs_dac_detector or needs_plugin:
        import_match = list(re.finditer(r'^import .+$', content_fixed, re.MULTILINE))
        if import_match:
            last_import_end = import_match[-1].end()
            insert_text = ""
            if needs_dac_state: insert_text += "\nimport com.bitperfect.plugin.usbdac.UsbDacState"
            if needs_dac_detector: insert_text += "\nimport com.bitperfect.plugin.usbdac.UsbAudioDacDetector"
            if needs_plugin: insert_text += "\nimport com.bitperfect.plugin.usbdac.UsbDacOutputPlugin"
            content_fixed = content_fixed[:last_import_end] + insert_text + content_fixed[last_import_end:]

    content_fixed = re.sub(r'import com\.bitperfect\.app\.usb\.UsbDacState\n?', '', content_fixed)
    content_fixed = re.sub(r'import com\.bitperfect\.app\.usb\.UsbAudioDacDetector\n?', '', content_fixed)
    content_fixed = re.sub(r'import com\.bitperfect\.app\.player\.UsbAudioRenderersFactory\n?', '', content_fixed)

    with open(filepath, 'w') as f:
        f.write(content_fixed)

files_to_fix = [
    'app/src/main/kotlin/com/bitperfect/app/BitPerfectApplication.kt',
    'app/src/main/kotlin/com/bitperfect/app/output/OutputRepository.kt',
    'app/src/main/kotlin/com/bitperfect/app/player/PlaybackService.kt',
    'app/src/main/kotlin/com/bitperfect/app/usb/DeviceStateManager.kt',
    'app/src/main/kotlin/com/bitperfect/app/ui/AppViewModel.kt',
    'app/src/main/kotlin/com/bitperfect/app/ui/OutputDeviceSheet.kt',
    'app/src/main/kotlin/com/bitperfect/app/MainActivity.kt'
]
for filepath in files_to_fix: fix_file(filepath)

package com.bitperfect.core.models

data class DiscMetadata(
    val albumTitle: String,
    val artistName: String,
    val trackTitles: List<String>,
    val mbReleaseId: String,
    val year: String? = null,
    val genre: String? = null,
    val albumArtist: String? = null,
    val discNumber: Int? = null,
    val totalDiscs: Int? = null,
    val releaseTags: List<String> = emptyList(),
    val trackTags: List<List<String>> = emptyList(),
    val hasFrontCoverArt: Boolean = false
)

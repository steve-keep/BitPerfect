import re
filepath = 'app/src/main/kotlin/com/bitperfect/app/player/PlaybackService.kt'
with open(filepath, 'r') as f:
    content = f.read()
needs_renderers = 'UsbAudioRenderersFactory' in content and 'import com.bitperfect.plugin.usbdac.UsbAudioRenderersFactory' not in content
if needs_renderers:
    import_match = list(re.finditer(r'^import .+$', content, re.MULTILINE))
    if import_match:
        last_import_end = import_match[-1].end()
        content = content[:last_import_end] + "\nimport com.bitperfect.plugin.usbdac.UsbAudioRenderersFactory" + content[last_import_end:]
with open(filepath, 'w') as f:
    f.write(content)
